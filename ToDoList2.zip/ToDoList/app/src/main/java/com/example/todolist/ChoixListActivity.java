package com.example.todolist;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ChoixListActivity extends AppCompatActivity implements View.OnClickListener, MyAdapter.ActionListener {

    private static String CAT = "ChoixListActivity";
    private String pseudo = null;
    private TextView edtCreerListe = null;
    private Button btnCreerListe = null;
    private RecyclerView recyclerView = null;
    private JSONArray jsonArray;

    private final static String BASE_URL = "http://tomnab.fr/todo-api/";
    private RequestQueue mQueue;


    // Fonction alerter()
    private void alerter(String s){
        Toast toastAlert = Toast.makeText(this, s, Toast.LENGTH_SHORT);
        toastAlert.show();
        Log.i(CAT, s);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choix_list);
//        alerter("onCreate: choixlist");

        // Récupération des views du layout
        edtCreerListe = findViewById(R.id.edtNewListe);
        btnCreerListe = findViewById(R.id.btnNewList);

        // ################# Gestionnaire de clic ########################
        btnCreerListe.setOnClickListener(this);
        edtCreerListe.setOnClickListener(this);

        mQueue = Volley.newRequestQueue(this);
        String url = BASE_URL + "/lists";
        String hash = recupHash();


        // ############### RecyclerView #################################
        recyclerView = findViewById(R.id.myRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager((this)));

        MyAdapter.ActionListener al = this;
        getRequestJsonArray(url, hash, al);
    }

    @Override
    protected void onStart() {
        super.onStart();

        // Récupération du bundle transmis par MainActivity: PSEUDO
        Bundle data = this.getIntent().getExtras();
        pseudo = data.getString("pseudo", "");
        pseudo = pseudo.toLowerCase();

        mQueue = Volley.newRequestQueue(this);
        String url = BASE_URL + "/lists";
        String hash = recupHash();


        // ############### RecyclerView #################################
        recyclerView = findViewById(R.id.myRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager((this)));

        MyAdapter.ActionListener al = this;
        getRequestJsonArray(url, hash, al);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    // Gestionnaire d'événement menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch(id){
            case R.id.action_account:
                alerter("Menu Compte");
                break;
            case R.id.action_settings:
                alerter("Menu Préférences");
                Intent toSettings = new Intent(this,SettingsActivity.class);
                startActivity(toSettings);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

        switch(v.getId()){
            case R.id.btnNewList:

                // Séquence 2 : Ajout d'une nouvelle liste
                String titreListe = edtCreerListe.getText().toString();
                String url = BASE_URL + "/lists";
                String hash = recupHash();
                postRequestCreationListe(url, hash, titreListe);

                // Actualisation du RecyclerView
                MyAdapter.ActionListener al = this;
                getRequestJsonArray(url, hash, al);

        }
    }

    /**
     *
     * @return le hash de l'utilisateur connecté
     */
    public String recupHash(){
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        String hash = settings.getString("hash", "");
//        alerter(hash);
        return hash;
    }

    /**
     *
     * @param posListe
     * au clic sur une liste, on démarre l'activité ShowListActivity en lui envoyant
     * l'id de la liste
     */
    @Override
    public void onItemClicked(int posListe) {

        Intent toShowListActivity = new Intent(ChoixListActivity.this, ShowListActivity.class);
        Bundle myBundle = new Bundle();

        JSONObject liste = null;
        try {
            liste = jsonArray.getJSONObject(posListe);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        int idListe = 0;
        try {
            idListe = liste.getInt("id");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        myBundle.putInt("idListe", idListe);

        // Démarrage de l'activité ShowListActivity
        toShowListActivity.putExtras(myBundle);
        startActivity(toShowListActivity);
    }

    /**
     *
     * @param url
     * @param hash
     * @param al
     * On va chercher les listes du profil connecté via une requête post. On sauvegarde ces
     * listes dans jsonArray
     */
    public void getRequestJsonArray(String url, String hash, final MyAdapter.ActionListener al){
        url = url + "?hash=" + hash;
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                url, null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                try {
                    jsonArray = response.getJSONArray("lists");
//                    alerter(jsonArray.get(0).getClass().toString());
                    recyclerView.setAdapter(new MyAdapter(jsonArray, al));

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                alerter("error");
            }
        });
        mQueue.add(jsonObjectRequest);

    }

    /**
     *
     * @param url
     * @param hash
     * @param label
     * On crée une nouvelle liste que l'on ajoute dans l'API via une requête post
     */
    public void postRequestCreationListe(String url, final String hash, final String label){
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        alerter("ajout de " + label);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                alerter("Echec");
            }
        }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("label", label);
                params.put("hash", hash);

                return params;
            }
        };
        mQueue.add(postRequest);
    }
}
