package com.example.todolist;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ShowListActivity extends AppCompatActivity implements View.OnClickListener, MyAdapterShowList.ActionListener {

    private int idListe;
    private Button btnCreerItem;
    private TextView edtCreerItem;
    RecyclerView recyclerView;

    JSONArray jsonArray;

    private final static String BASE_URL = "http://tomnab.fr/todo-api/lists/";
    private RequestQueue mQueue;

    String CAT = "PMR";

    // Fonction alerter()
    private void alerter(String s){
        Toast toastAlert = Toast.makeText(this, s, Toast.LENGTH_SHORT);
        toastAlert.show();
        Log.i(CAT, s);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_list);

        // Récupération des views du layout
        edtCreerItem = findViewById(R.id.edtNewItem);
        btnCreerItem = findViewById(R.id.btnNewItem);

        // ################# Gestionnaire de clic ########################
        btnCreerItem.setOnClickListener(this);
        edtCreerItem.setOnClickListener(this);

    }

    @Override
    protected void onStart() {
        super.onStart();

        // Récupération des infos de l'activité ChoixListeActivity
        Bundle myBundle = this.getIntent().getExtras();
        idListe = myBundle.getInt("idListe");

        // ############### RecyclerView #################################
        recyclerView = findViewById(R.id.myRecyclerViewItem);
        recyclerView.setLayoutManager(new LinearLayoutManager((this)));

        // Récupération des items à afficher
        mQueue = Volley.newRequestQueue(this);
        String url = BASE_URL + idListe + "/items";
        MyAdapterShowList.ActionListener al = this;
        String hash = recupHash();
        getRequestJsonArray(url, hash, al);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnNewItem:
                // Ajout d'un nouvel Item
                String descriptionItem = edtCreerItem.getText().toString();
                String url = BASE_URL + idListe + "/items";
                String hash = recupHash();
                postRequestCreationItem(url, hash, descriptionItem);

                // Actualisation de l'affichage des Items
                MyAdapterShowList.ActionListener al = this;
                getRequestJsonArray(url, hash, al);

        }
    }

    /**
     *
     * @param posItem
     * @param fait
     * @param v
     * Gestionnaire de clic sur un Item : checked/unchecked
     */
    @Override
    public void onItemClicked(int posItem, boolean fait, View v) {
        int idItem = 0;
        try {
            idItem = jsonArray.getJSONObject(posItem).getInt("id");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        switch (v.getId()){
            case R.id.cbFait:
                try {
                    String hash = recupHash();
                    String url = BASE_URL + idListe + "/items/" + idItem + "?check=";
                    int checked = jsonArray.getJSONObject(posItem).getInt("checked");
                    if (checked == 0){
                        putRequestCheck(url, hash, 1);
                    } else {
                        putRequestCheck(url, hash, 0);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;

            case R.id.item:
                try {
                    String hash = recupHash();
                    String url = BASE_URL + idListe + "/items/" + posItem + "?check=";
                    int checked = jsonArray.getJSONObject(posItem).getInt("checked");
                    if (checked == 0){
                        putRequestCheck(url, hash, 1);
                    } else {
                        putRequestCheck(url, hash, 0);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    alerter("error");
                }
                break;

            case R.id.containerItem:
                try {
                    String hash = recupHash();
                    String url = BASE_URL + idListe + "/items/" + posItem + "?check=";
                    int checked = jsonArray.getJSONObject(posItem).getInt("checked");
                    if (checked == 0){
                        putRequestCheck(url, hash, 1);
                    } else {
                        putRequestCheck(url, hash, 0);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
        }

    }

    /**
     *
     * @param url
     * @param hash
     * @param al
     * On récupère la liste des items via une requête post
     */
    public void getRequestJsonArray(String url, String hash, final MyAdapterShowList.ActionListener al){
        url = url + "?hash=" + hash;
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                url, null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                try {
                    jsonArray = response.getJSONArray("items");
//                    alerter(jsonArray.toString());
                    recyclerView.setAdapter(new MyAdapterShowList(jsonArray, al));

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                alerter("error");
            }
        });
        mQueue.add(jsonObjectRequest);

    }

    /**
     *
     * @param url
     * @param hash
     * @param label
     * On crée un nouvel item via une requête post
     */
    public void postRequestCreationItem(String url, final String hash, final String label){
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        alerter("ajout de " + label);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                alerter("Echec");
            }
        }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("label", label);
                params.put("hash", hash);

                return params;
            }
        };
        mQueue.add(postRequest);
    }

    /**
     *
     * @param url
     * @param hash
     * @param checked
     * On check/uncheck un item via une requête put
     */
    public void putRequestCheck(String url, String hash, int checked){
        final String urlFinale = url + checked + "&hash=" + hash;
        StringRequest putRequest = new StringRequest(Request.Method.PUT, urlFinale, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                alerter(urlFinale);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        mQueue.add(putRequest);
    }

    /**
     *
     * @return le hash de l'utilisateur connecté
     */
    public String recupHash(){
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        String hash = settings.getString("hash", "");
//        alerter(hash);
        return hash;
    }
}
