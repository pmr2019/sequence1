package com.example.todolist;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static String CAT = "PMR";
    private Button btnOk = null;
    private EditText edtPseudo = null;
    private EditText edtMdp = null;
    private Button btnReset;
    private final static String BASE_URL = "http://tomnab.fr/todo-api/";
    private RequestQueue mQueue;

    // Fonction alerter()
    private void alerter(String s){
        Toast toastAlert = Toast.makeText(this, s, Toast.LENGTH_SHORT);
        toastAlert.show();
        Log.i(CAT, s);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        alerter("onCreate");


        // On récupère les vues du layout par id
        btnOk = findViewById(R.id.btnOk);
        edtPseudo = findViewById(R.id.edtPseudo);
        edtMdp = findViewById(R.id.edtMdp);
        btnReset = findViewById(R.id.btnReset);

        // Mise en place d'un gestionnaire de clic
        btnOk.setOnClickListener(this);
        edtPseudo.setOnClickListener(this);
        btnReset.setOnClickListener(this);

    }

    @Override
    protected void onStart() {
        super.onStart();
//        alerter("onStart");
        String pseudo;

        // Récupération du Pseudo dans les préférences (niveau application)
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        // PSEUDO
        pseudo = settings.getString("pseudo", "");
        edtPseudo.setText(pseudo);

        // Seq 2
        // On teste la connexion au réseau, le bouton btnOk devient alors visible
        if (verifReseau()) btnOk.setVisibility(View.VISIBLE);
    }

    // Override de la méthode onClick()
    @Override
    public void onClick(View v) {
        // alerter("Clic");
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = settings.edit();

        switch (v.getId()){
            case R.id.btnOk:
                final String pseudo = edtPseudo.getText().toString();
                final String mdp = edtMdp.getText().toString();

                // Séquence 2
                // authentification via requête post
                mQueue = Volley.newRequestQueue(this);
                String url = BASE_URL + "authenticate";

                postRequest(url, pseudo, mdp);



                // Enregistrement du pseudo dans les préférences
                editor.putString("pseudo", pseudo);
                editor.commit();
//                alerter("Sauvegarde: " + pseudo);



                // Initialisation d'un Intent explicite
                Intent toChoixListActivity = new Intent(this,ChoixListActivity.class);

                // Initialisation d'un Bundle
                Bundle data = new Bundle();
                data.putString("pseudo", pseudo);
                toChoixListActivity.putExtras(data);

                // Changement d'activité
                startActivity(toChoixListActivity);

                break;
            case R.id.edtPseudo:
                alerter("Saisir votre pseudo");
                break;

            case R.id.btnReset:
                editor.clear();
                editor.commit();
                edtPseudo.setText("");
                alerter("Reset");
                break;
        }
    }

    // Affichage d'un menu
    // Instantiation
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    // Gestionnaire d'événement menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch(id){
            case R.id.action_account:
                alerter("Menu Compte");
                break;
            case R.id.action_settings:
                alerter("Menu Préférences");
                Intent toSettings = new Intent(this,SettingsActivity.class);
                startActivity(toSettings);
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    /**
     *
     * @param hash
     * Sauvegarde du hash dans les préférences partagées
     */
    public void sauvegardeHash(String hash){
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("hash", hash);
        editor.commit();
    }

    // ############# Séquence 2 #######################################################

    /**
     *
     * @return true si l'appli est connectée au réseau
     */
    public boolean verifReseau()
    {
        // On vérifie si le réseau est disponible,
        // si oui on change le statut du bouton de connexion
        ConnectivityManager cnMngr = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cnMngr.getActiveNetworkInfo();

        String sType = "Aucun réseau détecté";
        Boolean bStatut = false;
        if (netInfo != null)
        {

            NetworkInfo.State netState = netInfo.getState();

            if (netState.compareTo(NetworkInfo.State.CONNECTED) == 0)
            {
                bStatut = true;
                int netType= netInfo.getType();
                switch (netType)
                {
                    case ConnectivityManager.TYPE_MOBILE :
                        sType = "Réseau mobile détecté"; break;
                    case ConnectivityManager.TYPE_WIFI :
                        sType = "Réseau wifi détecté"; break;
                }

            }
        }

        this.alerter(sType);
        return bStatut;
    }

    /**
     *
     * @param url
     * @param pseudo
     * @param mdp
     * Authentification à l'API via requête post
     */
    public void postRequest(String url, final String pseudo, final String mdp){
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        String hash = parseData(response);
                        sauvegardeHash(hash);
//                        alerter(hash);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                alerter("Echec");
            }
        }){
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("user", pseudo);
                params.put("password", mdp);

                return params;
            }
        };
        mQueue.add(postRequest);
    }

    public String parseData(String response){
        try {
            JSONObject jsonObject = new JSONObject(response);
            String hash = jsonObject.getString("hash");
            return hash;
        } catch (JSONException e) {
            e.printStackTrace();
            return "echec";
        }

    }

}
