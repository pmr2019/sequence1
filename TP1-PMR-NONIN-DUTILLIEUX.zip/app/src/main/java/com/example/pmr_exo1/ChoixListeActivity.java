package com.example.pmr_exo1;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ChoixListeActivity extends ParentActivity {

    private static final String CAT = "Todo_ChoixListeActivity"; //Catégorie de log
    private EditText input;
    private ProfilListeTodo profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choix_liste);

        //Récupération des éléments du layout
        FloatingActionButton fab = findViewById(R.id.fab);
        RecyclerView recyclerView = findViewById(R.id.recycler_view);

        // retrieve parsed data from MainActivity
        Bundle data = this.getIntent().getExtras();
        String pseudo = data.getString("pseudo");

        // Set Activity label
        this.setTitle("Listes de " + pseudo);

        //_____________________ RECYCLER VIEW ________________________
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        // Désérialisation des données du ProfilListeTodo associées au pseudo récupéré
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        profile = ProfilListeTodo.fromJSON(settings.getString("profile_" + pseudo, ""));
        //Utilisation d'un adapter pour afficher toutes les listes associées au profile
        recyclerView.setAdapter(new ListeTodoAdapter(profile.getMesListeTodo(), pseudo));


        //_____________________ ALERT DIALOG BUILDER ________________________
        // Creating alert Dialog with one Button
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(ChoixListeActivity.this);
        // Setting Dialog Title
        alertDialog.setTitle(getResources().getString(R.string.add_list));

        //Ajout d'un EditText programmatiquement dans un AlertDialog
        alertDialog.setMessage(getResources().getString(R.string.list_name));
        input = new EditText(ChoixListeActivity.this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        input.setLayoutParams(lp);
        alertDialog.setView(input);

        //Gestion de la création d'une liste
        alertDialog.setPositiveButton(getResources().getString(R.string.create),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //Si on créé une nouvelle liste, on récupère son nom
                        String listName = input.getText().toString();
                        if (listName.equals("")) { //On vérifie que les données soient cohérentes
                            Toast.makeText(ChoixListeActivity.this,R.string.empty_field,Toast.LENGTH_SHORT).show();
                        }
                        else{//On créé la nouvelle liste et on l'ajoute aux préférences
                            addNewList(listName);
                        }
                        //Dans tous les cas on ferme la fenêtre de dialogue, et on vide l'EditText
                        dialog.dismiss();
                        alertDialog.create();
                        input.setText("");
                    }
                });

        //Gestion de l'annulation de la création
        alertDialog.setNegativeButton(getResources().getString(R.string.cancel),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        input.setText("");
                    }
                });

        final AlertDialog alert = alertDialog.create();


        //_____________________ ON NEW LIST CLICK ________________________
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alert.show();
            }
        });
    }

    //Permet de créer une nouvelle liste, de l'ajouter au ProfilListeTodo de l'activité, et de l'ajouter aux préférences
    private void addNewList(String listName) {
        //Enregistrement de la date d'ajout de la liste, création de la liste, et affectation au ProfilListeTodo
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM", Locale.FRANCE);
        String date = dateFormat.format(new Date());
        profile.ajouterListe(new ListeTodo(listName, date));

        Log.i("CAT", "Création de la liste " + listName);
        Log.i("CAT", "Mes listes : " + profile.toJSON(false));

        //Mise à jour des données dans les préférences (on écrase les données précédentes)
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("profile_" + profile.getLogin(), profile.toJSON(false));
        editor.apply();
    }

}
