package com.example.pmr_exo1;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SecondActivity extends ParentActivity {

    private final String CAT = "Todo_SecondActivity";
    private TextView traces;
    private String json_chaine = "{\"promo\":\"2018-2019\",\"label\":\"Programmation Mobile et Réalité Augmentée\",\"enseignants\":[{\"prenom\":\"Isabelle\",\"nom\":\"Le Glaz\"},{\"prenom\":\"Thomas\",\"nom\":\"Bourdeaud'huy\"}],\"effectifs\":[\"G1\",\"G2\"]}";

    private void afficherChaineJson(String chaine) {
        int i;

        try {
            JSONObject json_objet = new JSONObject(chaine);
            JSONArray profs = json_objet.getJSONArray("enseignants");
            for(i=0;i<profs.length();i++) {
                String prenom = ((JSONObject)profs.get(i)).getString("prenom");
                String nom = ((JSONObject) profs.get(i)).getString("nom");
                Log.i(CAT,prenom + " " + nom);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    public static String jsonToPrettyFormat(String jsonString) {
        JSONObject json = null;
        try {
            json = new JSONObject(jsonString);
            Gson gson = new GsonBuilder()
                    .serializeNulls()
                    .disableHtmlEscaping()
                    .setPrettyPrinting()
                    .create();

            return gson.toJson(json);
        } catch (JSONException e) {
            e.printStackTrace();
            return "chaine impossible à interpréter";
        }

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        traces = findViewById(R.id.tracesSecondeApp);

        // Récupération des données passées à l'activité dans un un bundle
        Bundle data = this.getIntent().getExtras();

        // Affichage (utiliser la méthode alerter ou afficher dans un TextView)
        traces.append("\nPseudo : ");
        traces.append(data.getString("pseudo","inconnu"));

        SharedPreferences settings  = PreferenceManager.getDefaultSharedPreferences(this);
        // heure de connexion
        String dateLogin = settings.getString("dateLogin","");
        String pseudo= settings.getString("pseudo","");
        Log.i(CAT, "pseudo contenu dans settings : "+ settings.getAll().containsKey("profile_" + pseudo));
        Log.i(CAT, "contendu des settings : " + settings.getAll().toString());
        ProfilListeTodo profile = ProfilListeTodo.fromJSON(settings.getString("profile_" + pseudo, ""));
        traces.append("\nContenu des préférences :");
        traces.append("\ndateLogin : " + dateLogin);
        traces.append("\npseudo : " + pseudo);
        traces.append("\nprofil : " + profile.getLogin());

        // Affichage d'un objet JSON
        //afficherChaineJson(json_chaine);

        // Affichage de la chaine initiale
        //Log.i(CAT,json_chaine);

        // Affichage de la chaine en "pretty printing"
        //Log.i(CAT,jsonToPrettyFormat(json_chaine));

        //String jsonListe = settings.getString("jsonString","error");
        //Log.v(CAT,jsonListe);
        //Log.v(CAT,ListeTodo.fromJSON(jsonListe).toString());
    }
}
