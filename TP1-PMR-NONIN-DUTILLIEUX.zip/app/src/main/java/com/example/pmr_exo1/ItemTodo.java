package com.example.pmr_exo1;

import java.io.Serializable;

public class ItemTodo implements Serializable {

    private boolean fait;
    private String description;

    public ItemTodo(String description, boolean fait) {
        this.setFait(fait);
        this.setDescription(description);
    }
    public ItemTodo(String description) {
        this(description,false);
    }
    public ItemTodo() {
        this("",false);
    }

    public boolean isFait() {
        return fait;
    }

    public void setFait(boolean fait) {
        this.fait = fait;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "\""+this.description+"\" : "+ (this.fait ? "Fait" : "Pas fait");
    }
}
