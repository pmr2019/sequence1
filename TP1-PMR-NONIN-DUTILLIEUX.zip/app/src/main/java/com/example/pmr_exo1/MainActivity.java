package com.example.pmr_exo1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.Preference;
import android.preference.PreferenceGroup;
import android.preference.PreferenceManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.support.v7.widget.Toolbar;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends ParentActivity implements View.OnClickListener {

    public final String CAT="Todo_MainActivity";

    private EditText edtPseudo = null;
    private Button btnOK = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        alerter("onCreate");

        edtPseudo = findViewById(R.id.edtPseudo);
        btnOK = findViewById(R.id.btnOK);

        edtPseudo.setOnClickListener(this);
        btnOK.setOnClickListener(this);

     }

    @Override
    protected void onStart() {
        super.onStart();
        alerter("onStart");

        // récupération des préférences au niveau Application
        SharedPreferences settings =
                PreferenceManager.getDefaultSharedPreferences(this);

        edtPseudo.setText(settings.getString("pseudo",""));

        // testListeToJSON();
    }

    @Override
    public void onClick(View v) {
        alerter("clic par l'activité qui implémente l'interface onClickListener");
        // Intérêt : permet de capturer des clics sur plusieurs éléments...
        // Démonstration :
        switch (v.getId()) {
            case R.id.btnOK :
                //Enregistrement du pseudo renseigné dans les préférences de l'application
                String pseudo = edtPseudo.getText().toString();
                SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
                SharedPreferences.Editor editor = settings.edit();

                //Déclarations préalables
                Class nextActivity;
                ProfilListeTodo profile;

                //Si le profil est connu (il a déjà été enregistré via une clef dans les préférences)
                if (settings.getAll().containsKey("profile_" + pseudo)) {
                    alerter("Vous êtes déjà inscrit.");
                    //On récupère le ProfilListeTodo sérialisé associé au profil, et on le désérialise
                    profile = ProfilListeTodo.fromJSON(settings.getString("profile_" + pseudo, ""));
                    Log.i(CAT, profile.getLogin() + " possède " + profile.getMesListeTodo().size() + " liste(s).");
                    //On s'apprête à lancer l'activité de choix de liste pour ce pseudo
                    nextActivity = ChoixListeActivity.class;
                } else { //Sinon, si le pseudo est inconnu
                    alerter("On ne vous connaît pas.");
                    //On lui créé un profil
                    profile = new ProfilListeTodo(pseudo);
                    //On l'ajoute aux préférence pour le garder en mémoire
                    editor.putString("profile_" + pseudo, profile.toJSON(false));
                    editor.apply();
                    Log.i(CAT, "On ajoute profile_" + pseudo + " dans les préférences : " + profile.toJSON(false));
                    //Et on s'apprête à regarder toutes les informations associées (SecondActivity)
                    nextActivity = SecondActivity.class;
                }

                //editor.clear();
                // Dans tous les cas, on enregistre le pseudo actuel comme pseudo par défaut dans les préférences
                editor.putString("pseudo",pseudo);
                // stocker le json dans les préférences
                // editor.putString("jsonString",testListeToJSON());

                // On stocke l'heure de la dernière connexion dans les préférences
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
                String dateLogin = sdf.format(new Date());
                editor.putString("dateLogin",dateLogin);

                //On commit toutes les modifications du fichier de préférence.
                editor.commit();
                //On prépare le passage à l'activité suivante (Soit ChoixListeActivity, soit SecondActivity si le pseudo n'est pas reconnu)
                Intent intent = new Intent(this, nextActivity);

                // Ajout d'un bundle de données contenant le pseudo
                Bundle data = new Bundle();
                data.putString("pseudo",pseudo);
                intent.putExtras(data);

                // Lancement de l'activité suivante
                startActivity(intent);

                break;

            case R.id.edtPseudo : //Si on clique sur le champ de texte
                alerter("Saisir votre pseudo"); //Alors on affiche un toast
                break;

        }
    }

    //Méthode de test de la sérialisation JSON des listes. Inutilisée en production.
    public String testListeToJSON(){
        ListeTodo maListe = new ListeTodo();
        for(int i=1; i<5;i++)
            maListe.ajouterItem(new ItemTodo("Todo n°"+i));
        //TODO : Afficher la liste dans le Log CAT
        Log.i(CAT,maListe.toString());
        // TODO: Sérialiser la liste
        Log.i(CAT,maListe.toJSON(true));
        Log.i(CAT,maListe.toJSON(false));

        return maListe.toJSON(false);
    }

}
