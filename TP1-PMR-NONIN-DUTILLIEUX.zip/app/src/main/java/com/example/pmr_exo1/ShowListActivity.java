package com.example.pmr_exo1;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

public class ShowListActivity extends ParentActivity {

    private static final String TAG = "Todo_ShowListActivity";
    private ProfilListeTodo profile;
    private EditText edtItem = null;
    private ListeTodo listeTodo;
    private SharedPreferences.Editor editor;
    private ItemTodoAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_list);

        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        editor = settings.edit();

        //Récupération de l'index de l'ItemTodo (envoyé avec l'Intent de création d'activity depuis le ListeTodoAdapter)
        int iListeTodo = Integer.parseInt(this.getIntent().getStringExtra("indexOfListeTodo"));
        String pseudo = this.getIntent().getStringExtra("pseudo");
        profile = ProfilListeTodo.fromJSON(settings.getString("profile_" + pseudo, ""));
        listeTodo = profile.getMesListeTodo().get(iListeTodo); //Récupération de toute la ListeTodo cliquée dans l'activité précédente

        // Set Activity label
        this.setTitle(listeTodo.getTitreListeTodo());

        //_____________________ RECYCLER VIEW ________________________
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        adapter = new ItemTodoAdapter(listeTodo.getLesItems());
        recyclerView.setAdapter(adapter);


        //_____________________ ADD ITEM_TODO ________________________

        FloatingActionButton fabAdd = findViewById(R.id.fabAdd);
        edtItem = findViewById(R.id.edtNewItem);
        fabAdd.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Log.i(TAG, "onClick bouton + : " + v);
                edtItem.onEditorAction(EditorInfo.IME_ACTION_DONE); //raise OnEditorActionListener
                edtItem.setText("");

            }
        });

        edtItem.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                Log.i(TAG, "onEditorAction");
                String descriptionNewItem = edtItem.getText().toString();
                if (descriptionNewItem.matches("")) {
                    Log.i(TAG, "L'utilisateur entre une todoItem vide !");
                }
                else { //Si l'entrée est valide, ajout dun nouvel item à la liste
                    //traces.append(descriptionNewItem);
                    listeTodo.ajouterItem(new ItemTodo(descriptionNewItem,false));
                    Log.i(TAG, "New Todo :" + profile.toString());
                    adapter.notifyItemInserted(listeTodo.getLesItems().size());

                    //Mise à jour des données dans les préférences (données précédentes écrasées)
                    editor.putString("profile_" + profile.getLogin(), profile.toJSON(false));
                    editor.apply();
                }
                return false;
            }
        });

    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG, "OnPause" + profile.toString());
        //Sauvegarde des données actuelles
        editor.putString("profile_" + profile.getLogin(), profile.toJSON(false));
        editor.apply();

    }

}
