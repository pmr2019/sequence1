package com.example.pmr_exo1;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.List;

public class ListeTodoAdapter extends RecyclerView.Adapter<ListeTodoAdapter.ListTodoViewHolder> {
    private static final String TAG = "Todo_ListeTodoAdapter";
    private List<ListeTodo> listeTodosList;
    private Context context;
    private String pseudo;

    public ListeTodoAdapter(List<ListeTodo> listeTodosList, String pseudo) {
        this.listeTodosList = listeTodosList;
        this.pseudo = pseudo;
    }

    @NonNull
    @Override
    public ListTodoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //On inflate le template associé à une ListeTodo, et on retourne la vue correspondante.
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemView = inflater.inflate(R.layout.liste_todo_item, parent, false);
        Log.i(TAG, "onCreateViewHolder() called with: parent = ["
                + parent
                + "], viewType = ["
                + viewType
                + "]");
        context = parent.getContext();
        return new ListTodoViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ListTodoViewHolder holder, final int position) {
        //On récupère la bonne ListeTodo. Afin de peupler à la vue déjà inflatée, on modifie ses contenus
        final ListeTodo listeTodo = listeTodosList.get(position);
        holder.title.setText(listeTodo.getTitreListeTodo());
        holder.date.setText(listeTodo.getDate());
        holder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lorsque l'on clique sur une ListeTodo, on démarre une ShoListActivity pour voir les items qu'elle contient
                Log.i(TAG, "onClick : cliqué sur " + listeTodo.getTitreListeTodo());
                Log.i(TAG, "onClick : cliqué sur élément n°" + position);

                //On démarre la nouvelle activité en envoyant le pseudo et l'index de la liste.
                Intent intent = new Intent(context, ShowListActivity.class);
                intent.putExtra("indexOfListeTodo", Integer.toString(position));
                intent.putExtra("pseudo", pseudo);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listeTodosList.size();
    }

    //Classe interne ListTodoViewHolder utilisée pour créer les vues et y peupler les données des ListeTodo.
    class ListTodoViewHolder extends RecyclerView.ViewHolder{
        public TextView title, date;
        public LinearLayout parentLayout;

        public ListTodoViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
            date = itemView.findViewById(R.id.date);
            parentLayout = itemView.findViewById(R.id.linear_layout);
        }
    }
}
