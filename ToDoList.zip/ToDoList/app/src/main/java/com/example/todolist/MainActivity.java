package com.example.todolist;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import modele.ItemToDo;
import modele.ListeToDo;
import modele.ProfilListeToDo;

import static java.lang.Float.valueOf;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "TEST" ;
    public static String USER;
    EditText edt_pseudo;
    Button btn_connexion;
    String nomFichier;
    ProfilListeToDo p;

    @Override
    protected void onStart() {
        super.onStart();
        edt_pseudo = findViewById(R.id.iEdt_pseudo);
        SharedPreferences settings =
                PreferenceManager.getDefaultSharedPreferences(this);
        edt_pseudo.setText(settings.getString("pseudo",""));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_connexion = findViewById(R.id.iBtn_SignIn);
        btn_connexion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                edt_pseudo = findViewById(R.id.iEdt_pseudo);
                String login = edt_pseudo.getText().toString();

                SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("pseudo",edt_pseudo.getText().toString());
                editor.commit();

                Intent choixListe = new Intent(MainActivity.this, ChoixListActivity.class);
                choixListe.putExtra(USER, login);
                startActivity(choixListe);

            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id){

            case R.id.iIt_test :
                Toast.makeText(this, "Clique sur l'item Test", Toast.LENGTH_SHORT).show();

            case R.id.iIt_pref :
                Toast.makeText(this, "Gérer ses préférences", Toast.LENGTH_SHORT).show();
                Intent settings = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(settings);
        }

        return super.onOptionsItemSelected(item);
    }




}
