package fr.ec.app.data.api;

import java.util.List;

public class PostResponseList {
 public List<PostResponse> posts ;
}
