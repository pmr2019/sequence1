package fr.ec.app.data.api;

import com.google.gson.annotations.SerializedName;

public class Thumbnail {

  @SerializedName("image_url")
  public String imageUrl;
}
